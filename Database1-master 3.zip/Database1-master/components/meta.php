<head>
    <meta charset="utf-8">
    <title> <? echo($title); ?></title>
    <meta name="description" content="プログラミング言語辞典">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta name="author" content="SitePoint">
    <link rel="stylesheet" href="./css/bulma.min.css">
</head>